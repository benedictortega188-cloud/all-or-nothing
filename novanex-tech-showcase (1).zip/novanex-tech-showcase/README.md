# NovaNex — Technology Showcase

NovaNex is an original, modern and minimalist technology showcase website created for Activity 01: ALL OR NOTHING.

## Website concept
**Technology Showcase** — introduces visitors to current technology topics such as artificial intelligence, green technology, space technology, smart devices, biotechnology, and cybersecurity.

## Built with
- HTML5
- CSS3

**JavaScript is not used.** The website uses standard HTML links and CSS-only visual effects and responsive layouts.

## Folder structure
```text
novanex-tech-showcase/
├── index.html
├── about.html
├── gallery.html
├── css/
│   └── style.css
├── images/
│   └── (reserved for optional image files)
└── README.md
```

## Run locally
1. Download or extract this project folder.
2. Open `index.html` in a web browser.
3. Use the navigation links to visit the Home, About, and Explore pages.

## Publish using GitHub Pages
1. Sign in to GitHub and create a **public** repository, for example `novanex-tech-showcase`.
2. Upload the contents of this folder. Make sure `index.html` is in the repository's root, not inside another nested folder.
3. Open the repository's **Settings**.
4. Select **Pages** from the left menu.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to finish publishing. The published address will appear in the Pages section and normally follows this format:
   `https://YOUR-USERNAME.github.io/novanex-tech-showcase/`
8. Open the published link and test all three pages and navigation links.

## Before submitting
- Confirm the repository is public.
- Confirm GitHub Pages is enabled.
- Test the website on both desktop and mobile screen sizes.
- Check that `index.html`, `about.html`, `gallery.html`, and `css/style.css` are uploaded in the correct locations.
- Keep the project JavaScript-free.

## Customization
You may edit the text, colors, and page content to make the project reflect your own ideas. If you add images, place them in the `images` folder and use relative paths such as `images/example.jpg`.
