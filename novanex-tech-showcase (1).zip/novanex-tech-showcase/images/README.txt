Place optional image files for your website in this folder. The current design uses CSS illustrations and does not require external images.
